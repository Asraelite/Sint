<?php
	$online = false;
	if($online){
		$server = 'sint.comli.com'
	}
	$con = msqli_connect()