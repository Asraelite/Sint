Sint
====

Download all files, put in folder, run index.php in a browser.
WASD and Arrow Keys to move.
N and M to shoot things.
