How to Play
====

Download at least sint.js, index.html and actors.png, other files are optional. 
Put in folder, run index.html in a browser.

WASD to move.
M, N and S to use moves, 
not all buttons may be used in every build.

Info
====

Version Alpha 0.3.2:

Level collision is working well for actors, not yet for
particles or collision between actors and particles.
